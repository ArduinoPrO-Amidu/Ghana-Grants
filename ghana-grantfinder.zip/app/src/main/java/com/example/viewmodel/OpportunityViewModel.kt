package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Opportunity
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.OpportunityRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class OpportunityFilter(
    val query: String = "",
    val category: String? = null,
    val applicantType: String? = null,
    val status: String? = null,
    val sort: SortOrder = SortOrder.NEWEST_FIRST
)

sealed interface OpportunityListUiState {
    data object Loading : OpportunityListUiState
    data class Success(val opportunities: List<Opportunity>) : OpportunityListUiState
    data class Error(val message: String) : OpportunityListUiState
}

enum class SortOrder {
    NEWEST_FIRST,
    CLOSING_SOONEST
}

class OpportunityViewModel(
    private val repository: OpportunityRepository,
    private val aiRepository: AiAssistantRepository? = null
) : ViewModel() {

    private val _rawOpportunities = repository.observeOpportunities()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _selectedApplicantType = MutableStateFlow<String?>(null)
    val selectedApplicantType: StateFlow<String?> = _selectedApplicantType.asStateFlow()

    private val _selectedStatus = MutableStateFlow<String?>(null)
    val selectedStatus: StateFlow<String?> = _selectedStatus.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.NEWEST_FIRST)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    // AI Smart Search states
    private val _isAiSearchActive = MutableStateFlow(false)
    val isAiSearchActive: StateFlow<Boolean> = _isAiSearchActive.asStateFlow()

    private val _isAiSearching = MutableStateFlow(false)
    val isAiSearching: StateFlow<Boolean> = _isAiSearching.asStateFlow()

    private val _aiSearchExplanation = MutableStateFlow<String?>(null)
    val aiSearchExplanation: StateFlow<String?> = _aiSearchExplanation.asStateFlow()

    private val _aiMatchingIds = MutableStateFlow<List<String>>(emptyList())

    private val _filterState = combine(
        _searchQuery,
        _selectedCategory,
        _selectedApplicantType,
        _selectedStatus,
        _sortOrder
    ) { query, category, applicantType, status, sort ->
        OpportunityFilter(query, category, applicantType, status, sort)
    }

    // Filtered list for Explore screen with Smart Token Search and AI Search support
    val filteredOpportunities: StateFlow<List<Opportunity>> = combine(
        _rawOpportunities,
        _filterState,
        _isAiSearchActive,
        _aiMatchingIds
    ) { opportunities, filter, isAiActive, aiIds ->
        val candidateList = if (isAiActive) {
            opportunities.filter { it.id in aiIds }
        } else {
            opportunities
        }

        // Tokenize query into meaningful search keywords
        val rawTokens = filter.query.trim().lowercase()
            .split("[\\s,]+".toRegex())
            .filter { it.isNotBlank() }

        val stopWords = setOf("for", "in", "a", "an", "the", "and", "or", "to", "of", "with", "is", "using", "by", "ai", "search", "looking", "find", "me", "some", "at", "on", "from")
        val effectiveTokens = if (rawTokens.all { it in stopWords }) rawTokens else rawTokens.filter { it !in stopWords }

        candidateList.filter { opp ->
            val matchesQuery = if (isAiActive) {
                true // AI has already pre-filtered to matching IDs
            } else if (effectiveTokens.isEmpty()) {
                true
            } else {
                val fullSearchableText = buildString {
                    append(opp.title).append(" ")
                    append(opp.organization).append(" ")
                    append(opp.shortDescription).append(" ")
                    append(opp.fullDescription).append(" ")
                    append(opp.category).append(" ")
                    append(opp.eligibleApplicantTypes.joinToString(" ")).append(" ")
                    append(opp.eligibilityCriteria.joinToString(" ")).append(" ")
                    append(opp.requiredDocuments.joinToString(" "))
                }.lowercase()

                effectiveTokens.any { token -> fullSearchableText.contains(token) }
            }

            val matchesCategory = filter.category == null || opp.category.equals(filter.category, ignoreCase = true)

            val matchesApplicant = filter.applicantType == null ||
                    opp.eligibleApplicantTypes.any { it.contains(filter.applicantType, ignoreCase = true) }

            val matchesStatus = filter.status == null ||
                    opp.opportunityStatus.equals(filter.status, ignoreCase = true)

            matchesQuery && matchesCategory && matchesApplicant && matchesStatus
        }.let { list ->
            if (!isAiActive && effectiveTokens.isNotEmpty()) {
                list.sortedByDescending { opp ->
                    var score = 0
                    val titleLower = opp.title.lowercase()
                    val catLower = opp.category.lowercase()
                    val orgLower = opp.organization.lowercase()
                    val descLower = opp.shortDescription.lowercase()
                    effectiveTokens.forEach { token ->
                        if (titleLower.contains(token)) score += 5
                        if (catLower.contains(token)) score += 4
                        if (orgLower.contains(token)) score += 3
                        if (descLower.contains(token)) score += 2
                    }
                    score
                }
            } else {
                when (filter.sort) {
                    SortOrder.NEWEST_FIRST -> list
                    SortOrder.CLOSING_SOONEST -> list.sortedBy { it.opportunityStatus != "closing_soon" }
                }
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    // Featured opportunities (first 4)
    val featuredOpportunities: StateFlow<List<Opportunity>> = _rawOpportunities
        .map { opps -> opps.take(4) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    // Closing soon opportunities
    val closingSoonOpportunities: StateFlow<List<Opportunity>> = _rawOpportunities
        .map { opps ->
            opps.filter { it.opportunityStatus == "closing_soon" || it.opportunityStatus == "open" }.take(3)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        // Reset AI search state if query is modified
        if (_isAiSearchActive.value) {
            _isAiSearchActive.value = false
            _aiSearchExplanation.value = null
        }
    }

    fun searchWithAi() {
        val query = _searchQuery.value.trim()
        if (query.isBlank() || _isAiSearching.value) return
        val currentOpps = _rawOpportunities.value
        if (currentOpps.isEmpty()) return

        val ai = aiRepository ?: return

        _isAiSearching.value = true
        viewModelScope.launch {
            try {
                val result = ai.searchOpportunitiesWithAi(query, currentOpps)
                result.fold(
                    onSuccess = { searchResult ->
                        _aiMatchingIds.value = searchResult.matchingOpportunityIds
                        _aiSearchExplanation.value = searchResult.explanation
                        _isAiSearchActive.value = true
                    },
                    onFailure = { err ->
                        _aiSearchExplanation.value = "AI Search: ${err.localizedMessage ?: "Unable to complete semantic search."}"
                        _isAiSearchActive.value = false
                    }
                )
            } finally {
                _isAiSearching.value = false
            }
        }
    }

    fun clearAiSearch() {
        _isAiSearchActive.value = false
        _aiMatchingIds.value = emptyList()
        _aiSearchExplanation.value = null
    }

    fun onCategorySelected(category: String?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun onApplicantTypeSelected(applicantType: String?) {
        _selectedApplicantType.value = if (_selectedApplicantType.value == applicantType) null else applicantType
    }

    fun onStatusSelected(status: String?) {
        _selectedStatus.value = if (_selectedStatus.value == status) null else status
    }

    fun onSortOrderChanged(sort: SortOrder) {
        _sortOrder.value = sort
    }

    fun clearAllFilters() {
        _searchQuery.value = ""
        _selectedCategory.value = null
        _selectedApplicantType.value = null
        _selectedStatus.value = null
        _sortOrder.value = SortOrder.NEWEST_FIRST
        clearAiSearch()
    }
}
